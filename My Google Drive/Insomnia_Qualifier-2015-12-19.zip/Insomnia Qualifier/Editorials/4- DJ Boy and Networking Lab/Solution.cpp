#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <iostream>
#include <list>
#include <vector>
#include <map>
#include <set>
using namespace std;

#define MS(A)	memset(A, 0, sizeof(A))
#define REP(i ,n) for(i = 0; i < (n); i++)
#define FOR(i, a, n) for(i = a; i < n; i++)

#define MAX 1000000
#define MOD 1000000007
#define INF (int(1e9))
#define PB push_back
typedef long long int LL;
typedef vector <int> vi;

vi *v;
map<string,int> mp;

bool cmp(vi x,vi y)
{
	if(x[3] == y[3])	return x[0] < y[0];
	return x[3] < y[3];
}	

int find(int x,int par[])
{
	if(par[x] != x)
		par[x] = find(par[x],par);
	return par[x];
}

void un(int x,int y,int par[],int rank[])
{
	if(rank[x] < rank[y])
		par[x] = y;
	else if(rank[x] > rank[y])
		par[y] = x;
	else
		++rank[x], par[y] = x;
}		

int main()
{
	int t,i,j,k,m,n;
	string x,y,z;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&m);
		v = new vi[m+n];
		mp.clear();	
		int ct=0, ind,id1,id2;
		REP(i,m+n)
		{
			cin >> x >> y >> z;
			ind = (x[0]-'A')*10 + (x[1]-'0');
			v[i].PB(ind);

			if(mp.find(y) == mp.end())
				mp[y] = ++ct, id1 = ct;
			else
				id1 = mp[y];
			v[i].PB(id1);
			
			if(mp.find(z) == mp.end())
				mp[z] = ++ct, id2 = ct;
			else
				id2 = mp[z];
			v[i].PB(id2);

			if(i < n)	k=0;
			else		scanf("%d",&k);
			v[i].PB(k);
		}	
		sort(v,v+m+n,cmp);
	
		int e=1,tot=0, par[50],rank[50], px,py;
		vector<string> ans;
		REP(i,50)
			par[i] = i, rank[i]=0;
		for(i=0;i<m+n && e < ct;i++)
		{
			px = find(v[i][1],par);		py = find(v[i][2],par);			
			if(px != py)
			{
				e++;
				un(px,py,par,rank);
				if(v[i][3] > 0)
				{
					string s = "";
					k = v[i][0] / 10;	s += ('A' + k);
					k = v[i][0] % 10;	s += ('0' + k);
					ans.PB(s); 		tot++;
				}
			}
		}
		
		if(e < ct)	printf("Impossible\n");
		else if(!tot)	printf("Not Required\n");
		else
		{
			sort(ans.begin(), ans.end());
			REP(i,tot)	cout << ans[i] << " ";
			cout << "\n";
		}
	}
	return 0;
}

