#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

long long dp[110][50000],a[101],n,m;

long long gao(long long s, int i){
    if(!s || !i) return s;
    if(s<50000 && dp[i][s] != -1) return dp[i][s];
    long long ret=s;
	for(int j=i;j>0;j--)
		ret-=gao(s/a[j],j-1);
    if(s<50000) dp[i][s]=ret;
    return ret;
}

int main(){
	int t;
	scanf("%d",&t);
	while(t--)
	{
    scanf("%lld%lld",&n,&m);
    for(int i=1;i<=m;i++) scanf("%lld",a+i);
    //memset(dp,255,sizeof(dp));
	long long x;
	x=(50000<n)?50000:n;
    for(int i=0;i<m+5;i++)
		for(int j=0;j<50000;j++)
			dp[i][j]=-1;
    sort(a,a+m);
    printf("%lld\n",gao(n,m));
	}
}