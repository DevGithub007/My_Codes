/*Mayoor Bishnoi*/

#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<vector>
#include<list>
#include<map>
#include<queue>
#include<stack>
#include<set>

#define inp(n) scanf("%d",&n);
#define inp2(x,y) scanf("%d%d",&x,&y);
#define inpl(n) scanf("%lld",&n);
#define inpl2(x,y) scanf("%lld%lld",&x,&y);
#define out(n) printf("%d\n",n);
#define outl(n) printf("%lld\n",n);
#define FOR(i,a,b) for(int i=a;i<b;i++)
#define FORR(i,b,a) for(int i=b-1;i>=a;i--)
#define PB(a) push_back(a)
#define C(x) printf("%d\n",x);
#define F first
#define S second
#define MAX 1000010

using namespace std;

typedef vector< int > vi;
typedef pair< int,int > pii;
typedef vector< pii > vpii;
typedef list< int > li;
typedef long long ll;
typedef unsigned long long ull;

/*int gcd(int a,int b)
{
	while(b)
		b^=a^=b^=a%=b;
	return a;
}*/

/*int mypower(int base,int index)
{
	if(index == 0)
		return 1;
	else if(index == 1)
		return base;
	int temp=mypower(base,index/2);
	temp=(temp*temp);
	if(index&1)
		return temp*base;
	else
		return temp;
}*/

int arr[100009],mx=0,mn=0;

int main()
{
	
    int t,n,x;
	inp(t)
	while(t--)
	{
		inp(n)
		mx=mn=0;
		FOR(i,0,n){
			scanf("%d",&arr[i]);
			if(arr[i] > arr[mx])mx=i;
			if(arr[i] <= arr[mn]) mn=i; 
		}
		printf("%d\n",n - mn -1 + mx - (mn < mx));
	}
    
    return 0;

}