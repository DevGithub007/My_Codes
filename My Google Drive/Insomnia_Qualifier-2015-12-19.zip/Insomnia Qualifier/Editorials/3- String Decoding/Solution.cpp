#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <iostream>
#include <list>
#include <vector>
#include <map>
#include <set>
using namespace std;

#define MS(A)	memset(A, 0, sizeof(A))
#define REP(i ,n) for(i = 0; i < n; i++)
#define FOR(i, a, n) for(i = a; i < n; i++)

#define MAX 1000000
#define MOD 1000000007
#define INF (int(1e9))
#define PB push_back
typedef long long int LL;
typedef vector <int> vi;

vi *v;

bool vis[60][120];
string num, res;
int ans;

void solve(int pos,int score,string cur)
{
	if(vis[pos][score])	return;
	vis[pos][score] = 1;
	if(pos >= num.size())
	{
		if(score > ans)	
		{
			ans = score;
			res = cur;
		}
	}
	
	set <char> s;
	for(int i=0;i<3;i++,pos++)
	{
		if(pos >= num.size())
			break;
		if(i==0 && cur != "")
			cur += "-";
		cur += num[pos];
		s.insert(num[pos]);
		if(i == 1)
        		solve(pos+1, score + (s.size() == 1? 2: 0), cur);
      		else if(i == 2)
        		solve(pos+1, score + 3 - s.size(), cur);
	}
}

int main()
{
	int t,i,j,k,n;
	scanf("%d",&t);
	while(t--)
	{
		cin >> num;
		ans = -1; 	
		MS(vis);
		solve(0,0,"");
		cout << res << "\n";
	}
	return 0;
}
		

