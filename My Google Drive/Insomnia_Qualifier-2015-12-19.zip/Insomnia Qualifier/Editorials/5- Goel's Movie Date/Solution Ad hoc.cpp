#include<iostream>
#include<cstdio>
using namespace std;
int main() {
    int t;
    scanf("%d",&t);
    while(t--){
        int n,q,A[10005];
        scanf("%d",&n);
        for(int i=0;i<n;i++)
            scanf("%d",&A[i]);
        scanf("%d",&q);
        for(int i=0;i<q;i++){
            int a,b,c,d;
            scanf("%d%d%d",&a,&b,&c);
            if(a==1)
                A[b-1]=c;
            else {
                int H[1005]={0},s=0,u=0,f=-1;
                scanf("%d",&d);
                for(int j=b-1;j<c;j++)
                    H[A[j]]++;
                for(int j=0;j<1005;j++){
                    u=s+H[j];
                    if(s<=d&&u>=d){
                        f=j;
                        break;
                    }
                    s=u;
                }
                printf("%d\n",f);
            }
        }
    }
    return 0;
}
