#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
const int xmax=10000,ymax=1000;
int bit[10002][1002];

void update(int x,int y,int val){
	int y1;
	while(x<=xmax){
		y1=y;
		while(y1<=ymax){
			bit[x][y1]+=val;
			y1+=(y1&-y1);
		}
		x+=(x&-x);
	}
}

int read(int x,int y){
	int sum=0,y1=0;
	while(x>0){
		y1=y;
		while(y1>0){
			sum+=bit[x][y1];
			y1-=(y1&-y1);
		}
		x-=(x&-x);
	}
    return sum;
}

int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		memset(bit,0,sizeof(bit));
		int n;
		scanf("%d",&n);
		int arr[n+2],i;
		for(i=1;i<=n;i++){
			scanf("%d",&arr[i]);
			update(i,arr[i],1);
		}
		int q;
		scanf("%d",&q);
		while(q--){
			int p;
			scanf("%d",&p);
			if(p){
				int x,k;
				scanf("%d%d",&x,&k);
				update(x,arr[x],-1);
				arr[x]=k;
				update(x,arr[x],1);
			}
			else{
				int l,r,k;
				scanf("%d%d%d",&l,&r,&k);
				int low=1;
				int high=ymax;
				int ans=-1;
				while(low<=high){
					int mid=(low+high)/2;
					int x1=read(r,mid);
					int x2=read(l-1,mid);
					if(x1-x2>=k){
						ans=mid;
						high=mid-1;
					}
					else
						low=mid+1;
				}
				printf("%d\n",ans);
			}
		}
	}
	return 0;
}